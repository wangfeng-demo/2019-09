<template>
    <div>
    所有客户
    </div>
</template>
<script>
// @ is an alias to /src
export default {
    name: 'all',
    data() {
        return {
        
        }
    },
    components: {
        
    }
}
</script>
<style lang="less">

</style>