<template>
    <div>
     我的客户   
    </div>
</template>
<script>
// @ is an alias to /src
export default {
    name: 'my',
    data() {
        return {
        
        }
    },
    components: {
        
    }
}
</script>
<style lang="less">

</style>